public class LetValExp extends Expr {
  String arg1 = new String();
  Expr arg2, arg3 ;
  Env env ;
  Value v ;
  Value endresult = null ;
  LetValExp(String _arg1, Expr _arg2, Expr _arg3) {
    arg1 = _arg1 ;
    arg2 = _arg2 ;
    arg3 = _arg3 ;
  }
  public Value eval(Env E) throws EvalError{
    Value result = null ;
    result = arg2.eval(E) ;
    if (result instanceof IntVal) {
      IntVal temp = (IntVal)result ;
      v = new IntVal(temp.value) ;
    }
    else if (result instanceof BoolVal){
      BoolVal temp = (BoolVal)result ;
      v = new BoolVal(temp.value) ;
    }
    else {
      FunVal temp = (FunVal)result ;
      v = temp ;
    }
    if (arg3 instanceof AppExp){
      return arg3.eval(E) ;
    }
    try {
      if (result instanceof IntVal) {
        env = E.updateBinding(arg1,new IntVal(((IntVal)result).value)) ;
      }
      else if (result instanceof BoolVal) {
        env = E.updateBinding(arg1,new BoolVal(((BoolVal)result).value)) ;
      }
      else {
        FunVal fv = (FunVal)result;
        env = E.updateBinding(arg1,fv) ;
      }
    }
    catch(Exception e) {
        if (result instanceof IntVal) {
          env = E.addBinding(arg1,new IntVal(((IntVal)result).value)) ;
        }
        else if (result instanceof BoolVal) {
          env = E.addBinding(arg1,new BoolVal(((BoolVal)result).value)) ;
        }
        else {
            FunVal fv = (FunVal)result;
            env = E.addBinding(arg1,fv) ;
        }
    }
    endresult = arg3.eval(env) ;
    return endresult ;
  }
  public String toString() {
    return "(let val " + arg1.toString() + " = " + arg2.toString() + " in " + arg3.toString() + " end)";
  }
}

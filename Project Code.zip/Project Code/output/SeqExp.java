public class SeqExp extends Expr {
  Expr expr1, expr2 ;
  Value v  ;
  SeqExp(Expr _expr1, Expr _expr2) {
    expr1 = _expr1 ;
    expr2 = _expr2 ;
  }
  public Value eval(Env E) {
    try {
      expr1.eval(E) ;
      v = expr2.eval(E) ;
    }
    catch(EvalError err) {
      System.out.println(err.getMessage()) ;
    }
    return v ;
  }
  public String toString() {
    return "{ " + expr1.toString() + " ; " + expr2.toString() + " } " ;
  }
}

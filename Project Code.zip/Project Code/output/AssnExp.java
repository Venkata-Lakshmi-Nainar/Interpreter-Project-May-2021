public class AssnExp extends Expr {
  String arg1 = new String() ;
  Expr arg2 ;
  Value result ;
  Env env ;
  AssnExp(String _arg1, Expr _arg2) {
    arg1 = _arg1 ;
    arg2 = _arg2 ;
  }
  public Value eval(Env E) throws EvalError{
      Value v = arg2.eval(E) ;
      if (v instanceof IntVal) {
        result = (IntVal)v ;
      }
      else if(v instanceof BoolVal) {
        result = (BoolVal)v ;
      }
      else {
        throw new EvalError() ;
      }
    if(((E.lookup(arg1)).getClass()).equals(result.getClass())) {
        env = E.updateBinding(arg1,result) ;
        return result ;
    }
      throw new EvalError("Error: Incompatible argument types");
  }
  public String toString() {
    return "(" + arg1 + ":=" + arg2.toString() +")" ;
  }
}

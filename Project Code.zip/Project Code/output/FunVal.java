public class FunVal extends Value {
  String str = new String();
  Expr expr = null;
  Env env = null;
  FunVal(String _str, Expr _expr, Env _env) {
    str = _str ;
    expr = _expr ;
    env = _env ;
  }
  public String toString(){
    return "" ;
  }
}

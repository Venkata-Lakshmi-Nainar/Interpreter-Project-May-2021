public class BinExp extends Expr {
  final Expr arg1;
  final Expr arg2;
  final BinOp binoptr ;
  Value result = null ;
  BinExp(BinOp _binoptr, Expr _arg1, Expr _arg2){
    binoptr = _binoptr ;
    arg1 = _arg1 ;
    arg2 = _arg2 ;
  }
  public String toString() {
    String expression = new String() ;
    String p1 = arg1.toString() ;
    String p2 = new String() ;
    String p3 = arg2.toString() ;
    switch (binoptr){
      case PLUS:
        p2 = "+" ;
        break ;
      case MINUS:
        p2 = "-" ;
        break ;
      case TIMES:
        p2 = "*" ;
        break ;
      case DIV:
        p2 = "/" ;
        break ;
      case EQ:
        p2 = "=" ;
        break ;
      case LT:
        p2 = "<" ;
        break ;
      case AND:
        p2 = "&" ;
        break ;
      case OR:
        p2 = "|" ;
        break ;
    }
    return "(" + p1 + p2 + p3 +")" ;
  }

  public Value eval(Env e) throws EvalError {
      switch(binoptr){
        case PLUS:
        {
          IntVal temp1 = (IntVal)(arg1.eval(e)) ;
          IntVal temp2 = (IntVal)(arg2.eval(e)) ;
          return new IntVal(temp1.value + temp2.value) ;
        }

        case MINUS:
        {
          IntVal temp1 = (IntVal)(arg1.eval(e)) ;
          IntVal temp2 = (IntVal)(arg2.eval(e)) ;
          return new IntVal(temp1.value - temp2.value) ;
        }

        case TIMES:
        {
          IntVal temp1 = (IntVal)(arg1.eval(e)) ;
          IntVal temp2 = (IntVal)(arg2.eval(e)) ;
          return new IntVal(temp1.value * temp2.value) ;
        }

        case DIV:
        {
          IntVal temp1 = (IntVal)(arg1.eval(e)) ;
          IntVal temp2 = (IntVal)(arg2.eval(e)) ;
          return new IntVal(temp1.value / temp2.value) ;
        }

        case EQ:
        {
          Value val1 = arg1.eval(e) ;
          Value val2 = arg2.eval(e) ;

          if ( val1 instanceof IntVal && val2 instanceof IntVal ) {
            IntVal temp1 = (IntVal)(arg1.eval(e)) ;
            IntVal temp2 = (IntVal)(arg2.eval(e)) ;

            if (temp1.value == temp2.value) {
              return (new BoolVal(true)) ;
            }
              return (new BoolVal(false)) ;
          }
          else if ( val1 instanceof BoolVal && val2 instanceof BoolVal ) {
            BoolVal temp1 = (BoolVal)(arg1.eval(e)) ;
            BoolVal temp2 = (BoolVal)(arg2.eval(e)) ;
            if (temp1.value == temp2.value) {
              return (new BoolVal(true)) ;
            }
              return (new BoolVal(false)) ;
          }
          else {
            throw new EvalError("Incompatible Argument Types") ;
            //return (new BoolVal(false)) ;
          }
        }
        case LT:
        {
          IntVal temp1 = (IntVal)(arg1.eval(e)) ;
          IntVal temp2 = (IntVal)(arg2.eval(e)) ;

          if (temp1.value < temp2.value) {
            return (new BoolVal(true)) ;
          }
            return (new BoolVal(false)) ;
        }

        case AND:
        {
          BoolVal temp1 = (BoolVal)(arg1.eval(e)) ;
          if (temp1.value == false) {
            return (new BoolVal(false)) ;
          }
          BoolVal temp2 = (BoolVal)(arg2.eval(e)) ;
          if (temp2.value == true) {
            return (new BoolVal(true)) ;
          }
            return (new BoolVal(false)) ;
        }

        case OR:
        {
          BoolVal temp1 = (BoolVal)(arg1.eval(e)) ;
          if (temp1.value == true) {
            return (new BoolVal(true)) ;
          }
          BoolVal temp2 = (BoolVal)(arg2.eval(e)) ;
          if (temp2.value == true) {
            return (new BoolVal(true)) ;
          }
            return (new BoolVal(false)) ;
        }

        default:
          throw new EvalError("Evaluation error: Incompatible arg types") ;
      }
    }
}

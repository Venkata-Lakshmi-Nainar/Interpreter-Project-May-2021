public class VarExp extends Expr {
  String arg1 = new String();
  Env env1 = new EnvImp();
  Env env2 ;
  Value v ;
  VarExp(String _arg1) {
    arg1 = _arg1 ;
  }
  public Value eval(Env e) throws EvalError {
    v = e.lookup(arg1) ;
    return v ;
  }
  public String toString() {
    return arg1.toString() ;
  }
}

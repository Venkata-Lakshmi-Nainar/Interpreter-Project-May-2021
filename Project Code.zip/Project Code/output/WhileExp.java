public class WhileExp extends Expr {
  Expr arg1, arg2 ;
  WhileExp(Expr _arg1, Expr _arg2) {
    arg1 = _arg1 ;
    arg2 = _arg2 ;
  }
  public Value eval(Env E) {
    Value v ;
    try {
      while(((BoolVal)arg1.eval(E)).value == true) {
        arg2.eval(E) ;
      }
    }
    catch (EvalError err) {
      System.out.println(err.getMessage()) ;
    }
    return new BoolVal(false) ;
  }
  public String toString() {
    return "(while " + arg1.toString() + " do " + arg2.toString() +")" ;
  }
}

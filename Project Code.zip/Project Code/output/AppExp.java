public class AppExp extends Expr {
  String str ;
  Expr expr ;
  Value result = null ;
  AppExp(String _str, Expr _expr) {
    str = _str ;
    expr = _expr ;
  }
  public Value eval(Env E) {
    Env env ;
    Value vf ;
    FunVal fv = null;
    try {
      vf = E.lookup(str) ;
      fv = (FunVal)vf ;
      Value v = expr.eval(E) ;
      env = fv.env.addBinding(fv.str,v);
      result = fv.expr.eval(env) ;
    }
    catch(EvalError err) {
      System.out.println(err.getMessage()) ;
    }
    return result ;
  }
  public String toString(){
    return str + "(" + expr.toString() + ")" ;
  }
}

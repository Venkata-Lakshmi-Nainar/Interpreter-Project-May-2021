public class IfExp extends Expr {
  Expr arg1, arg2, arg3 ;
  Value result ;
  IfExp(Expr _arg1, Expr _arg2, Expr _arg3) {
    arg1 = _arg1 ;
    arg2 = _arg2 ;
    arg3 = _arg3 ;
  }
  public Value eval(Env E) {
    try {
      Value v = arg1.eval(E) ;
      BoolVal bv = (BoolVal)v ;
      if(bv.value == true) {
        result = arg2.eval(E) ;
      }
      else {
        result = arg3.eval(E) ;
      }
    }
    catch(EvalError err) {
      System.out.println("Eval Error:" + err.getMessage() ) ;
    }
    return result ;
  }
  public String toString() {
    return "(if " + arg1.toString() + " then " + arg2.toString() + " else " + arg3.toString() +") " ;
  }
}

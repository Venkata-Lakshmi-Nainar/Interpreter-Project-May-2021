public enum BinOp {
    PLUS,
    MINUS,
    TIMES,
    DIV,
    EQ,   
    LT,
    AND,
    OR
}

public class LetFunExp extends Expr{
  String str1, str2 ;
  Expr expr1, expr2 ;
  Env curenv, newenv ;
  Value result = null;
  LetFunExp(String _str1, String _str2, Expr _expr1, Expr _expr2) {
    str1 = _str1 ;
    str2 = _str2 ;
    expr1 = _expr1 ;
    expr2 = _expr2 ;
  }
  public Value eval(Env E) {
    FunVal fv = new FunVal(str2,expr1,E) ;
    try {
      curenv = E.addBinding(str1,fv) ;
      fv = new FunVal(str2,expr1,curenv) ;
      newenv = curenv.updateBinding(str1,fv) ;
      result = expr2.eval(newenv) ;
    }
    catch (EvalError err) {
      System.out.println(err.getMessage()) ;
    }
    return result ;
  }
  public String toString(){
    return "(let fun " + str1 + "(" + str2 + ") = " + expr1.toString() + " in " + expr2.toString() + " end)";
  }
}
